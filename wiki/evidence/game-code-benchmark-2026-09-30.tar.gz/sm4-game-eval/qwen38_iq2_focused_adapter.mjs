import response from './qwen38_iq2_focused.mjs'
export const resolveExplosions = response.resolveExplosions
