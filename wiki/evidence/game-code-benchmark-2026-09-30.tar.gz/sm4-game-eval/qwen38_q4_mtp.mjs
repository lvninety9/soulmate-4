```javascript
// arena.mjs

const DIRS = [
  [0, -1], // U
  [0, 1],  // D
  [-1, 0], // L
  [1, 0],  // R
];

function deepCopy(state) {
  return {
    board: state.board.map(row => row.slice()),
    players: state.players.map(p => ({ ...p })),
    bombs: state.bombs.map(b => ({ ...b })),
    turn: state.turn,
    winner: state.winner,
    lastBlast: state.lastBlast.map(c => c.slice()),
  };
}

function inBounds(board, x, y) {
  return y >= 0 && y < board.length && x >= 0 && x < board[y].length;
}

function isFloor(board, x, y) {
  return inBounds(board, x, y) && board[y][x] === '.';
}

function cellHasPlayer(players, x, y, excludeIndex) {
  return players.some((p, i) => i !== excludeIndex && p.x === x && p.y === y);
}

function cellHasBomb(bombs, x, y) {
  return bombs.some(b => b.x === x && b.y === y);
}

function applyAction(state, playerIndex, action) {
  const player = state.players[playerIndex];
  if (player.hp <= 0) return;

  const { x, y } = player;

  if (action === 'U' || action === 'D' || action === 'L' || action === 'R') {
    const dir = DIRS.find(d => {
      if (action === 'U') return d[1] === -1;
      if (action === 'D') return d[1] === 1;
      if (action === 'L') return d[0] === -1;
      if (action === 'R') return d[0] === 1;
      return false;
    });
    const nx = x + dir[0];
    const ny = y + dir[1];
    if (isFloor(state.board, nx, ny) && !cellHasPlayer(state.players, nx, ny, playerIndex) && !cellHasBomb(state.bombs, nx, ny)) {
      player.x = nx;
      player.y = ny;
    }
  } else if (action === 'B') {
    const hasOwnBomb = state.bombs.some(b => b.owner === playerIndex);
    if (!hasOwnBomb && !cellHasBomb(state.bombs, x, y)) {
      state.bombs.push({ x, y, owner: playerIndex, timer: 2, range: 2 });
    }
  }
  // 'S' or invalid: do nothing
}

function computeBlastCells(board, bombs, explodedSet) {
  const blastSet = new Set();
  const queue = [];
  const toExplode = new Set();

  // Find all bombs that should explode this turn
  for (const bomb of bombs) {
    if (bomb.timer <= 0) {
      toExplode.add(bomb);
    }
  }

  // Process chain reactions
  let changed = true;
  while (changed) {
    changed = false;
    for (const bomb of bombs) {
      if (toExplode.has(bomb)) continue;
      // Check if this bomb is in the blast of any already-to-explode bomb
      // We need to compute blast cells of toExplode bombs and see if they hit this bomb
      // But we need to do this iteratively. Let's compute blast cells for current toExplode set.
    }
  }

  // Better approach: iterative expansion
  const exploding = new Set();
  const initialToExplode = bombs.filter(b => b.timer <= 0);
  for (const b of initialToExplode) exploding.add(b);

  let changed = true;
  while (changed) {
    changed = false;
    // Compute all blast cells from currently exploding bombs
    const currentBlast = new Set();
    for (const bomb of exploding) {
      const cells = getBlastCellsForBomb(board, bomb);
      for (const cell of cells) {
        currentBlast.add(cell);
      }
    }
    // Check if any non-exploding bomb is in the blast
    for (const bomb of bombs) {
      if (exploding.has(bomb)) continue;
      const key = `${bomb.x},${bomb.y}`;
      if (currentBlast.has(key)) {
        exploding.add(bomb);
        changed = true;
      }
    }
  }

  // Now compute final blast cells from all exploding bombs
  for (const bomb of exploding) {
    const cells = getBlastCellsForBomb(board, bomb);
    for (const cell of cells) {
      blastSet.add(cell);
    }
  }

  return { blastSet, exploding };
}

function getBlastCellsForBomb(board, bomb) {
  const cells = new Set();
  const { x, y, range } = bomb;
  cells.add(`${x},${y}`);

  const directions = [[0, -1], [0, 1], [-1, 0], [1, 0]];
  for (const [dx, dy] of directions) {
    for (let i = 1; i <= range; i++) {
      const nx = x + dx * i;
      const ny = y + dy * i;
      if (!inBounds(board, nx, ny)) break;
      const cellChar = board[ny][nx];
      if (cellChar === '#') break;
      cells.add(`${nx},${ny}`);
      if (cellChar === '+') break;
    }
  }

  return cells;
}

export function step(state, actions) {
  // Deep copy to avoid mutation
  const newState = deepCopy(state);

  // If winner is already set, return unchanged deep copy
  if (state.winner !== null) {
    return newState;
  }

  // Resolve player 0's action, then player 1's
  for (let i = 0; i < 2; i++) {
    const action = actions[i];
    applyAction(newState, i, action);
  }

  // Decrease each older bomb's timer by one
  // "Older" means bombs that existed before this turn's actions
  // We need to track which bombs were just planted
  const plantedThisTurn = new Set();
  // Actually, we can identify planted bombs by checking if they were in the original state
  // But we already mutated newState.bombs. Let's track differently.
  // The spec says: "A newly planted bomb does not tick on its planting turn"
  // So we need to know which bombs were planted this turn.
  // Let's re-do: track planted bombs during action resolution.

  // Let me restructure: we need to know which bombs are new.
  // Let's redo the action resolution with tracking.

  // Reset and redo
  const state2 = deepCopy(state);
  if (state.winner !== null) {
    return state2;
  }

  const plantedThisTurn = new Set();
  for (let i = 0; i < 2; i++) {
    const action = actions[i];
    const player = state2.players[i];
    if (player.hp <= 0) continue;

    const { x, y } = player;

    if (action === 'U' || action === 'D' || action === 'L' || action === 'R') {
      const dir = DIRS.find(d => {
        if (action === 'U') return d[1] === -1;
        if (action === 'D') return d[1] === 1;
        if (action === 'L') return d[0] === -1;
        if (action === 'R') return d[0] === 1;
        return false;
      });
      const nx = x + dir[0];
      const ny = y + dir[1];
      if (isFloor(state2.board, nx, ny) && !cellHasPlayer(state2.players, nx, ny, i) && !cellHasBomb(state2.bombs, nx, ny)) {
        player.x = nx;
        player.y = ny;
      }
    } else if (action === 'B') {
      const hasOwnBomb = state2.bombs.some(b => b.owner === i);
      if (!hasOwnBomb && !cellHasBomb(state2.bombs, x, y)) {
        const newBomb = { x, y, owner: i, timer: 2, range: 2 };
        state2.bombs.push(newBomb);
        plantedThisTurn.add(newBomb);
      }
    }
  }

  // Decrease each older bomb's timer by one
  for (const bomb of state2.bombs) {
    if (!plantedThisTurn.has(bomb)) {
      bomb.timer -= 1;
    }
  }

  // Bombs at timer <= 0 explode. Chain reactions.
  const { blastSet, exploding } = computeBlastCells(state2.board, state2.bombs, null);

  // Convert blastSet to array of [x, y]
  const lastBlast = [];
  for (const key of blastSet) {
    const [x, y] = key.split(',').map(Number);
    lastBlast.push([x, y]);
  }
  lastBlast.sort((a, b) => a[1] - b[1] || a[0] - b[0]);

  // Destroy crates: for each blasted cell, if it was '+', change to '.'
  // Use the board as it was before explosions for every ray (already done in getBlastCellsForBomb)
  // Now apply destruction
  for (const key of blastSet) {
    const [x, y] = key.split(',').map(Number);
    if (state2.board[y][x] === '+') {
      state2.board[y] = state2.board[y].slice(0, x) + '.' + state2.board[y].slice(x + 1);
    }
  }

  // Remove all exploded bombs
  state2.bombs = state2.bombs.filter(b => !exploding.has(b));

  // Apply damage to players
  for (const player of state2.players) {
    const key = `${player.x},${player.y}`;
    if (blastSet.has(key)) {
      player.hp = Math.max(0, player.hp - 1);
    }
  }

  // Determine winner
  const p0Alive = state2.players[0].hp > 0;
  const p1Alive = state2.players[1].hp > 0;
  if (p0Alive && !p1Alive) {
    state2.winner = 0;
  } else if (!p0Alive &&