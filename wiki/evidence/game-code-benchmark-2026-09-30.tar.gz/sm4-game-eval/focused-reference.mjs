import { step } from './reference.mjs'

export function resolveExplosions(board, bombs, players) {
  const out = step({ board, bombs, players, turn: 0, winner: null, lastBlast: [] }, ['S', 'S'])
  return { board: out.board, bombs: out.bombs, players: out.players, blast: out.lastBlast }
}
