import assert from 'node:assert/strict'
import { pathToFileURL } from 'node:url'

const file = process.argv[2]
const results = []
let resolveExplosions
try {
  ;({ resolveExplosions } = await import(pathToFileURL(file).href + '?run=' + Date.now()))
  assert.equal(typeof resolveExplosions, 'function')
} catch (error) {
  console.log(JSON.stringify({ file, loadError: String(error), score: 0, total: 10, results }, null, 2))
  process.exit(0)
}
const board = ['#######', '#.....#', '#..+..#', '#.....#', '#######']
const players = [{ x: 1, y: 1, hp: 3 }, { x: 5, y: 3, hp: 3 }]
const bomb = (x, y, timer = 1, range = 2, owner = 0) => ({ x, y, owner, timer, range })
const has = (out, x, y) => out.blast.some(([a, b]) => a === x && b === y)
function run(name, fn) {
  try { fn(); results.push({ name, pass: true }) }
  catch (error) { results.push({ name, pass: false, error: String(error) }) }
}

run('timers tick without blast; nested inputs stay unchanged', () => {
  const b = [...board], bs = [bomb(2, 1, 3)], ps = structuredClone(players)
  const out = resolveExplosions(b, bs, ps)
  assert.deepEqual(out.blast, [])
  assert.deepEqual(out.bombs, [bomb(2, 1, 2)])
  assert.deepEqual(out.board, b)
  assert.deepEqual(out.players, ps)
  assert.notStrictEqual(out.board, b)
  assert.notStrictEqual(out.bombs[0], bs[0])
  assert.notStrictEqual(out.players[0], ps[0])
  assert.deepEqual(bs, [bomb(2, 1, 3)])
})

run('single explosion makes a cross and sorted unique cells', () => {
  const out = resolveExplosions(board, [bomb(2, 1, 1, 2)], players)
  assert.deepEqual(out.blast, [[1, 1], [2, 1], [3, 1], [4, 1], [2, 2], [2, 3]])
  assert.equal(out.bombs.length, 0)
})

run('permanent wall blocks without entering blast', () => {
  const b = ['#######', '#..#..#', '#.....#', '#.....#', '#######']
  const out = resolveExplosions(b, [bomb(1, 1, 1, 4)], players)
  assert(has(out, 2, 1))
  assert(!has(out, 3, 1))
  assert(!has(out, 4, 1))
})

run('crate enters blast, is destroyed, and stops ray', () => {
  const out = resolveExplosions(board, [bomb(1, 2, 1, 4)], players)
  assert(has(out, 3, 2))
  assert(!has(out, 4, 2))
  assert.equal(out.board[2][3], '.')
  assert.equal(board[2][3], '+')
})

run('chain-trigger reaches cells beyond first bomb range', () => {
  const b = ['#######', '#.....#', '#.....#', '#.....#', '#######']
  const out = resolveExplosions(b, [bomb(1, 1, 1, 2), bomb(3, 1, 4, 2, 1)], players)
  assert.equal(out.bombs.length, 0)
  assert(has(out, 5, 1))
})

run('crate blocks chain based on original board', () => {
  const b = ['#######', '#..+..#', '#.....#', '#.....#', '#######']
  const out = resolveExplosions(b, [bomb(1, 1, 1, 4), bomb(5, 1, 4, 2, 1)], players)
  assert.equal(out.board[1][3], '.')
  assert.deepEqual(out.bombs, [bomb(5, 1, 3, 2, 1)])
})

run('overlapping blasts damage once and blast has no duplicates', () => {
  const b = ['#######', '#.....#', '#.....#', '#.....#', '#######']
  const ps = [{ x: 2, y: 1, hp: 3 }, { x: 5, y: 3, hp: 3 }]
  const out = resolveExplosions(b, [bomb(1, 1), bomb(3, 1, 1, 2, 1)], ps)
  assert.equal(out.players[0].hp, 2)
  assert.equal(new Set(out.blast.map(p => p.join(','))).size, out.blast.length)
})

run('each player damaged and hp clamped at zero', () => {
  const b = ['#######', '#.....#', '#.....#', '#.....#', '#######']
  const ps = [{ x: 1, y: 1, hp: 1 }, { x: 2, y: 1, hp: 1 }]
  const out = resolveExplosions(b, [bomb(1, 1)], ps)
  assert.deepEqual(out.players.map(p => p.hp), [0, 0])
})

run('three-bomb chain terminates and removes all', () => {
  const b = ['#########', '#.......#', '#.......#', '#########']
  const out = resolveExplosions(b, [bomb(1, 1, 1, 2), bomb(3, 1, 8, 2, 1), bomb(5, 1, 9, 2, 0)], players)
  assert.equal(out.bombs.length, 0)
  assert(has(out, 7, 1))
})

run('result preserves survivor fields and board dimensions', () => {
  const bs = [bomb(2, 1, 1, 1, 0), bomb(5, 3, 5, 3, 1)]
  const snapshot = structuredClone(bs)
  const out = resolveExplosions(board, bs, players)
  assert.deepEqual(bs, snapshot)
  assert.deepEqual(out.bombs, [bomb(5, 3, 4, 3, 1)])
  assert.equal(out.board.length, board.length)
  assert(out.board.every((row, i) => row.length === board[i].length))
})

console.log(JSON.stringify({ file, score: results.filter(x => x.pass).length, total: results.length, results }, null, 2))
