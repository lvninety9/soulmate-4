export function resolveExplosions(board, bombs, players) {
  const rows = board.length;
  const cols = board[0].length;

  // Deep copy board
  const boardCopy = board.map(row => row.slice());

  // Deep copy bombs with decremented timers
  const bombCopy = bombs.map(b => ({ ...b, timer: b.timer - 1 }));

  // Deep copy players
  const playerCopy = players.map(p => ({ ...p }));

  // Track which bombs have detonated
  const detonated = new Set();
  const blastSet = new Set(); // set of "x,y" strings

  // Helper: check if a cell is in bounds
  function inBounds(x, y) {
    return x >= 0 && x < cols && y >= 0 && y < rows;
  }

  // Helper: get cell value from original board
  function getCell(x, y) {
    return board[y][x];
  }

  // Helper: add a cell to blast set
  function addBlast(x, y) {
    const key = `${x},${y}`;
    if (!blastSet.has(key)) {
      blastSet.add(key);
    }
  }

  // Helper: process a single bomb explosion, returning newly detonated bomb indices
  function explodeBomb(bombIndex) {
    if (detonated.has(bombIndex)) return [];
    detonated.add(bombIndex);

    const bomb = bombCopy[bombIndex];
    const { x: bx, y: by, range } = bomb;

    // Add the bomb's own cell to blast
    addBlast(bx, by);

    const newlyDetonated = [];

    // Four cardinal directions: up, down, left, right
    const directions = [
      [0, -1],
      [0, 1],
      [-1, 0],
      [1, 0]
    ];

    for (const [dx, dy] of directions) {
      let cx = bx + dx;
      let cy = by + dy;
      for (let step = 1; step <= range; step++) {
        if (!inBounds(cx, cy)) break;

        const cell = getCell(cx, cy);

        // Wall blocks before entering the blast
        if (cell === '#') {
          break;
        }

        // Add this cell to blast
        addBlast(cx, cy);

        // Check if this cell has a bomb
        for (let i = 0; i < bombCopy.length; i++) {
          if (detonated.has(i)) continue;
          if (bombCopy[i].x === cx && bombCopy[i].y === cy) {
            newlyDetonated.push(i);
          }
        }

        // Crate enters the blast but stops its ray
        if (cell === '+') {
          break;
        }

        cx += dx;
        cy += dy;
      }
    }

    return newlyDetonated;
  }

  // Process initial explosions (timer <= 0)
  const queue = [];
  for (let i = 0; i < bombCopy.length; i++) {
    if (bombCopy[i].timer <= 0) {
      queue.push(i);
    }
  }

  // Process chain reactions
  while (queue.length > 0) {
    const idx = queue.shift();
    const newlyDetonated = explodeBomb(idx);
    for (const ni of newlyDetonated) {
      if (!detonated.has(ni)) {
        queue.push(ni);
      }
    }
  }

  // If no bomb exploded, return early with decremented timers
  if (detonated.size === 0) {
    const blast = [];
    return {
      board: boardCopy,
      bombs: bombCopy,
      players: playerCopy,
      blast
    };
  }

  // Apply damage to players: each player on any blasted cell loses exactly 1 hp
  for (const player of playerCopy) {
    const key = `${player.x},${player.y}`;
    if (blastSet.has(key)) {
      player.hp = Math.max(0, player.hp - 1);
    }
  }

  // Update board: blasted crates become floor
  for (const key of blastSet) {
    const [xStr, yStr] = key.split(',');
    const x = parseInt(xStr, 10);
    const y = parseInt(yStr, 10);
    if (boardCopy[y][x] === '+') {
      boardCopy[y] = boardCopy[y].slice(0, x) + '.' + boardCopy[y].slice(x + 1);
    }
  }

  // Remove detonated bombs
  const remainingBombs = bombCopy.filter((_, i) => !detonated.has(i));

  // Build blast array of [x, y] pairs sorted by y then x
  const blast = [];
  for (const key of blastSet) {
    const [xStr, yStr] = key.split(',');
    blast.push([parseInt(xStr, 10), parseInt(yStr, 10)]);
  }
  blast.sort((a, b) => {
    if (a[1] !== b[1]) return a[1] - b[1];
    return a[0] - b[0];
  });

  return {
    board: boardCopy,
    bombs: remainingBombs,
    players: playerCopy,
    blast
  };
}
