import hashlib
import json
import pathlib
import re
import sys
import time
import urllib.request


port = int(sys.argv[1])
label = sys.argv[2]
root = pathlib.Path('/tmp/sm4-game-eval')
prompt_file = sys.argv[3] if len(sys.argv) > 3 else 'prompt.txt'
prompt = (root / prompt_file).read_text()
max_tokens = int(sys.argv[4]) if len(sys.argv) > 4 else 2500
payload = {
    'model': 'local',
    'messages': [{'role': 'user', 'content': prompt}],
    'temperature': 0,
    'max_tokens': max_tokens,
    'stream': False,
}
request = urllib.request.Request(
    f'http://127.0.0.1:{port}/v1/chat/completions',
    json.dumps(payload).encode(),
    {'Content-Type': 'application/json'},
)
start = time.monotonic()
with urllib.request.urlopen(request, timeout=10800) as response:
    data = json.load(response)
elapsed = time.monotonic() - start
message = data['choices'][0]['message']
raw = message.get('content', '') or ''
stripped = raw.strip()
format_status = 'plain_code'
match = re.fullmatch(r'```(?:javascript|js|mjs)?\s*\n(.*?)\n```', stripped, re.S | re.I)
if match:
    code = match.group(1) + '\n'
    format_status = 'fenced_code'
else:
    match = re.search(r'```(?:javascript|js|mjs)?\s*\n(.*?)\n```', raw, re.S | re.I)
    if match:
        code = match.group(1) + '\n'
        format_status = 'prose_plus_code'
    else:
        code = raw
        if not raw.lstrip().startswith(('export ', 'function ', 'const ', 'let ', 'var ', 'import ')):
            format_status = 'other'

record = {
    'label': label,
    'port': port,
    'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
    'max_tokens': max_tokens,
    'elapsed_s': round(elapsed, 3),
    'usage': data.get('usage'),
    'timings': data.get('timings'),
    'finish_reason': data['choices'][0].get('finish_reason'),
    'format_status': format_status,
    'raw': raw,
    'reasoning_content': message.get('reasoning_content'),
}
(root / f'{label}.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
(root / f'{label}.mjs').write_text(code)
print(json.dumps({k: record[k] for k in ('label', 'elapsed_s', 'usage', 'timings', 'finish_reason', 'format_status')}, ensure_ascii=False), flush=True)
