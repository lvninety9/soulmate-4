const resolveExplosions = (board, bombs, players) => {
  // Deep-copy inputs so no mutation leaks out.
  const origBoard = board.map(row => row.slice());
  const origBombs = bombs.map(b => ({ x: b.x, y: b.y, owner: b.owner, timer: b.timer, range: b.range }));
  const origPlayers = players.map(p => ({ x: p.x, y: p.y, hp: p.hp }));

  // Step 1: decrement every bomb timer by 1.
  const decremented = origBombs.map(b => ({ ...b, timer: b.timer - 1 }));

  // Step 2: find bombs with timer <= 0.
  const initialDetonations = decremented.filter(b => b.timer <= 0);

  // Step 3: chain explosions until stable.
  const detonated = new Set();
  const blastCells = new Set();
  const queue = initialDetonations.map(b => b);

  while (queue.length > 0) {
    const bomb = queue.shift();
    if (detonated.has(bomb)) continue;
    detonated.add(bomb);

    // Compute blast cells for this bomb.
    const cells = computeBlastCells(bomb, origBoard);
    for (const c of cells) {
      blastCells.add(`${c.x},${c.y}`);
    }

    // Any bomb whose cell is in this blast detonates immediately.
    for (const b of decremented) {
      if (!detonated.has(b) && blastCells.has(`${b.x},${b.y}`)) {
        queue.push(b);
      }
    }
  }

  // Step 4: apply hp loss to players on any blasted cell.
  const newPlayers = origPlayers.map(p => {
    const hit = blastCells.has(`${p.x},${p.y}`);
    return { x: p.x, y: p.y, hp: hit ? Math.max(0, p.hp - 1) : p.hp };
  });

  // Step 5: build final board — only blasted crates become floor.
  const newBoard = origBoard.map(row => row.slice());
  for (const key of blastCells) {
    const [x, y] = key.split(',').map(Number);
    if (origBoard[y][x] === '+') {
      newBoard[y] = newBoard[y].slice().replace('#', '#').replace('+', '.').replace('.', '.');
      newBoard[y] = newBoard[y].slice(0, x) + '.' + newBoard[y].slice(x + 1);
    }
  }

  // Step 6: remove all detonated bombs.
  const newBombs = decremented.filter(b => !detonated.has(b));

  // Step 7: build sorted unique blast list.
  const blast = [...blastCells].map(k => {
    const [x, y] = k.split(',').map(Number);
    return [x, y];
  }).sort((a, b) => a[1] - b[1] || a[0] - b[0]);

  return { board: newBoard, bombs: newBombs, players: newPlayers, blast };
};

function computeBlastCells(bomb, origBoard) {
  const cells = new Set();
  cells.add(`${bomb.x},${bomb.y}`);

  const dirs = [[0, 1], [0, -1], [1, 0], [-1, 0]];
  for (const [dx, dy] of dirs) {
    let x = bomb.x + dx;
    let y = bomb.y + dy;
    for (let i = 0; i < bomb.range; i++) {
      if (x < 0 || y < 0 || x >= origBoard[0].length || y >= origBoard.length) break;
      if (origBoard[y][x] === '#') break;
      cells.add(`${x},${y}`);
      x += dx;
      y += dy;
    }
  }

  return [...cells].map(k => {
    const [x, y] = k.split(',').map(Number);
    return { x, y };
  });
}

export default { resolveExplosions };
