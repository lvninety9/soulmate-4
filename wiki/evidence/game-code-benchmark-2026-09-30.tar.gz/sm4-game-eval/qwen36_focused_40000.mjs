/**
 * Resolves explosions for a two-player grid game.
 * @param {string[]} board - The game board.
 * @param {{x: number, y: number, owner: number, timer: number, range: number}[]} bombs - The bombs.
 * @param {{x: number, y: number, hp: number}[]} players - The players.
 * @returns {{board: string[], bombs: any[], players: any[], blast: [number, number][]}}
 */
export function resolveExplosions(board, bombs, players) {
  // Deep copy inputs to ensure immutability
  const currentBoard = board.map(row => row.split(''));
  const currentBombs = bombs.map(b => ({ ...b }));
  const currentPlayers = players.map(p => ({ ...p }));

  // 1. Decrement timers
  for (const bomb of currentBombs) {
    bomb.timer -= 1;
  }

  // 2. Resolve explosions (handling chains)
  const blastCells = new Set();
  const explodedIndices = new Set();
  let queue = [];

  // Find initial bombs to explode
  for (let i = 0; i < currentBombs.length; i++) {
    if (currentBombs[i].timer <= 0) {
      queue.push(i);
    }
  }

  while (queue.length > 0) {
    const bombIndex = queue.shift();
    if (explodedIndices.has(bombIndex)) continue;
    explodedIndices.add(bombIndex);

    const bomb = currentBombs[bombIndex];
    const { x, y, range } = bomb;

    // Directions: Up, Down, Left, Right
    const directions = [
      [0, -1], [0, 1], [-1, 0], [1, 0]
    ];

    for (const [dx, dy] of directions) {
      for (let step = 1; step <= range; step++) {
        const nx = x + dx * step;
        const ny = y + dy * step;

        // Check bounds
        if (ny < 0 || ny >= currentBoard.length || nx < 0 || nx >= currentBoard[0].length) {
          break; // Out of bounds stops the ray
        }

        const cell = currentBoard[ny][nx];

        // Add to blast set
        blastCells.add(`${nx},${ny}`);

        if (cell === '#') {
          // Wall blocks the ray
          break;
        } else if (cell === '+') {
          // Crate is destroyed and blocks the ray
          break;
        } else if (cell === '.') {
          // Floor, continue ray
          continue;
        } else {
          // It's a bomb
          // Find the index of the bomb at this location
          const targetBombIndex = currentBombs.findIndex(b => b.x === nx && b.y === ny);
          if (targetBombIndex !== -1 && !explodedIndices.has(targetBombIndex)) {
            // Chain reaction: add to queue if not already processed
            queue.push(targetBombIndex);
          }
          // Blast passes through bombs? Usually in Bomberman, bombs don't block blast.
          // The prompt says "If a blast touches any bomb, that bomb explodes immediately".
          // It doesn't explicitly say bombs block. Standard rules: bombs do not block.
          continue;
        }
      }
    }
  }

  // 3. Apply changes to board and players
  // Convert Set to array for sorting later
  const blastArray = Array.from(blastCells).map(str => {
    const [x, y] = str.split(',').map(Number);
    return [x, y];
  });

  // Sort blast by y then x
  blastArray.sort((a, b) => {
    if (a[1] !== b[1]) return a[1] - b[1];
    return a[0] - b[0];
  });

  // Update board: Crates become floor
  for (const [x, y] of blastArray) {
    if (currentBoard[y][x] === '+') {
      currentBoard[y][x] = '.';
    }
  }

  // Update players: Lose 1 HP if on a blasted cell
  for (const player of currentPlayers) {
    if (blastCells.has(`${player.x},${player.y}`)) {
      player.hp -= 1;
      if (player.hp < 0) player.hp = 0;
    }
  }

  // Remove detonated bombs
  const remainingBombs = currentBombs.filter((_, index) => !explodedIndices.has(index));

  return {
    board: currentBoard.map(row => row.join('')),
    bombs: remainingBombs,
    players: currentPlayers,
    blast: blastArray
  };
}
