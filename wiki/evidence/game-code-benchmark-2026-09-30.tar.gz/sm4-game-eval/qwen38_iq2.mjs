const EMPTY = '.';
const WALL = '#';
const CRATE = '+';

function cloneState(state) {
  return {
    board: state.board.map(row => row.slice()),
    players: state.players.map(p => ({ x: p.x, y: p.y, hp: p.hp })),
    bombs: state.bombs.map(b => ({ x: b.x, y: b.y, owner: b.owner, timer: b.timer, range: b.range })),
    turn: state.turn,
    winner: state.winner,
    lastBlast: state.lastBlast.map(c => c.slice())
  };
}

function isFloor(board, x, y) {
  return board[y][x] === EMPTY;
}

function isWall(board, x, y) {
  return board[y][x] === WALL;
}

function isCrate(board, x, y) {
  return board[y][x] === CRATE;
}

function inBounds(board, x, y) {
  return x >= 0 && y >= 0 && x < board[0].length && y < board.length;
}

function hasBombAt(bombs, x, y) {
  return bombs.some(b => b.x === x && b.y === y);
}

function hasPlayerAt(players, x, y) {
  return players.some(p => p.x === x && p.y === y);
}

function movePlayer(state, index, action) {
  const player = state.players[index];
  if (player.hp <= 0) return;

  let dx = 0, dy = 0;
  if (action === 'U') dy = -1;
  else if (action === 'D') dy = 1;
  else if (action === 'L') dx = -1;
  else if (action === 'R') dx = 1;

  const nx = player.x + dx;
  const ny = player.y + dy;

  if (!inBounds(state.board, nx, ny)) return;
  if (!isFloor(state.board, nx, ny)) return;
  if (hasPlayerAt(state.players, nx, ny)) return;
  if (hasBombAt(state.bombs, nx, ny)) return;

  state.players[index].x = nx;
  state.players[index].y = ny;
}

function plantBomb(state, index) {
  const player = state.players[index];
  if (player.hp <= 0) return;

  if (state.bombs.some(b => b.owner === index)) return;
  if (hasBombAt(state.bombs, player.x, player.y)) return;

  state.bombs.push({ x: player.x, y: player.y, owner: index, timer: 2, range: 2 });
}

function resolveAction(state, index, action) {
  if (action === 'B') {
    plantBomb(state, index);
  } else {
    movePlayer(state, index, action);
  }
}

function getBlastCells(bomb, board) {
  const cells = new Set();
  const dirs = [[0, -1], [0, 1], [-1, 0], [1, 0]];

  for (const [dx, dy] of dirs) {
    let x = bomb.x + dx;
    let y = bomb.y + dy;
    for (let i = 0; i < bomb.range; i++) {
      if (!inBounds(board, x, y)) break;
      if (isWall(board, x, y)) break;
      cells.add(`${x},${y}`);
      x += dx;
      y += dy;
    }
  }

  return cells;}

function processExplosions(state) {
  const blastSet = new Set();
  const destroyed = new Set();
  const queue = state.bombs.filter(b => b.timer <= 0);

  while (queue.length > 0) {
    const bomb = queue.shift();
    const cells = getBlastCells(bomb, state.board);

    for (const cell of cells) {
      const [x, y] = cell.split(',').map(Number);
      blastSet.add(`${x},${y}`);

      if (isCrate(state.board, x, y)) {
        destroyed.add(`${x},${y}`);
      }
    }

    for (const b of state.bombs) {
      if (b.timer > 0 && cells.has(`${b.x},${b.y}`)) {
        queue.push(b);
      }
    }
  }

  for (const cell of destroyed) {
    const [x, y] = cell.split(',').map(Number);
    state.board[y][x] = EMPTY;
  }

  state.bombs = state.bombs.filter(b => b.timer > 0);

  return blastSet;
}

function applyBlast(state, blastSet) {
  for (const player of state.players) {
    if (player.hp <= 0) continue;
    if (blastSet.has(`${player.x},${player.y}`)) {
      player.hp = Math.max(0, player.hp - 1);
    }
  }
}

function determineWinner(state) {
  const alive = state.players.filter(p => p.hp > 0);
  if (alive.length === 0) {
    state.winner = -1;
  } else if (alive.length === 1) {
    state.winner = alive[0].x === state.players[0].x && alive[0].y === state.players[0].y ? 0 : 1;
  } else {
    state.winner = null;
  }
}

export function step(state, actions) {
  if (state.winner !== null) {
    return cloneState(state);
  }

  const next = cloneState(state);
  next.turn = state.turn + 1;

  resolveAction(next, 0, actions[0]);
  resolveAction(next, 1, actions[1]);

  next.bombs = next.bombs.map(b => ({ ...b, timer: b.timer - 1 }));

  const blastSet = processExplosions(next);
  applyBlast(next, blastSet);

  const blastCells = [...blastSet].map(c => c.split(',').map(Number)).sort((a, b) => a[1] - b[1] || a[0] - b[0]);
  next.lastBlast = blastCells;

  determineWinner(next);

  return next;
}
