# Fixed review rubric

The prompt and `grade.mjs` were written and hashed before any model response.

- Functional correctness: 14 independent checks, 5 points each (70).
- Delivery: complete ES module, exact `step` export, no prose/fence, no package dependency (10).
- Code quality: readable helpers and explicit turn phases; no needless duplicate state or brittle special cases (10).
- Robustness: finite chain processing, stable crate semantics, nested immutability, bounded work for a normal board (10).

The last three categories are reviewed from saved source and must cite concrete code behavior.
The automated score is reported separately from subjective scores. No repair prompts or test feedback
are given to a model before all three first-pass outputs are collected.
