export function step(state, actions) {
  const next = structuredClone(state)
  if (next.winner !== null) return next
  next.turn += 1
  next.lastBlast = []
  const oldCount = next.bombs.length
  const deltas = { U: [0, -1], D: [0, 1], L: [-1, 0], R: [1, 0] }

  for (let i = 0; i < 2; i++) {
    const p = next.players[i]
    if (p.hp <= 0) continue
    const action = actions[i]
    if (action === 'B') {
      const occupied = next.bombs.some(b => b.x === p.x && b.y === p.y)
      const owned = next.bombs.some(b => b.owner === i)
      if (!occupied && !owned) next.bombs.push({ x: p.x, y: p.y, owner: i, timer: 2, range: 2 })
    } else if (action in deltas) {
      const [dx, dy] = deltas[action]
      const x = p.x + dx
      const y = p.y + dy
      const free = next.board[y]?.[x] === '.' &&
        !next.players.some((other, j) => j !== i && other.x === x && other.y === y) &&
        !next.bombs.some(b => b.x === x && b.y === y)
      if (free) { p.x = x; p.y = y }
    }
  }

  for (let i = 0; i < oldCount; i++) next.bombs[i].timer -= 1
  const queue = []
  const detonated = new Set()
  const blast = new Set()
  for (let i = 0; i < next.bombs.length; i++) if (next.bombs[i].timer <= 0) queue.push(i)
  const originalBoard = next.board
  while (queue.length) {
    const index = queue.shift()
    if (detonated.has(index)) continue
    detonated.add(index)
    const bomb = next.bombs[index]
    const cells = [[bomb.x, bomb.y]]
    for (const [dx, dy] of [[0, -1], [0, 1], [-1, 0], [1, 0]]) {
      for (let dist = 1; dist <= bomb.range; dist++) {
        const x = bomb.x + dx * dist
        const y = bomb.y + dy * dist
        const tile = originalBoard[y]?.[x]
        if (tile === undefined || tile === '#') break
        cells.push([x, y])
        if (tile === '+') break
      }
    }
    for (const [x, y] of cells) {
      blast.add(`${x},${y}`)
      for (let j = 0; j < next.bombs.length; j++) {
        const other = next.bombs[j]
        if (other.x === x && other.y === y && !detonated.has(j)) queue.push(j)
      }
    }
  }

  const rows = next.board.map(row => [...row])
  next.lastBlast = [...blast].map(cell => cell.split(',').map(Number))
    .sort((a, b) => a[1] - b[1] || a[0] - b[0])
  for (const [x, y] of next.lastBlast) if (rows[y][x] === '+') rows[y][x] = '.'
  next.board = rows.map(row => row.join(''))
  next.bombs = next.bombs.filter((_, i) => !detonated.has(i))
  for (const p of next.players) {
    if (p.hp > 0 && blast.has(`${p.x},${p.y}`)) p.hp = Math.max(0, p.hp - 1)
  }
  const alive = next.players.map(p => p.hp > 0)
  if (!alive[0] && !alive[1]) next.winner = -1
  else if (!alive[0]) next.winner = 1
  else if (!alive[1]) next.winner = 0
  return next
}
