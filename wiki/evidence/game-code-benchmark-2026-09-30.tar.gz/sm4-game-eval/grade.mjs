import fs from 'node:fs'
import assert from 'node:assert/strict'
import { pathToFileURL } from 'node:url'

const file = process.argv[2]
if (!file) throw new Error('usage: node grade.mjs <model-output.mjs>')
const results = []
let step
try {
  ;({ step } = await import(pathToFileURL(file).href + '?run=' + Date.now()))
  assert.equal(typeof step, 'function')
} catch (error) {
  console.log(JSON.stringify({ file, loadError: String(error), score: 0, total: 14, results }, null, 2))
  process.exit(0)
}

const defaultBoard = [
  '#######',
  '#.....#',
  '#..+..#',
  '#.....#',
  '#######',
]
function state({ board = defaultBoard, players = [{ x: 1, y: 1, hp: 2 }, { x: 5, y: 3, hp: 2 }], bombs = [], turn = 0, winner = null, lastBlast = [] } = {}) {
  return structuredClone({ board, players, bombs, turn, winner, lastBlast })
}
function blastHas(s, x, y) {
  return s.lastBlast.some(([bx, by]) => bx === x && by === y)
}
function run(name, fn) {
  try {
    fn()
    results.push({ name, pass: true })
  } catch (error) {
    results.push({ name, pass: false, error: String(error) })
  }
}

run('moves both players and does not mutate input', () => {
  const before = state()
  const snapshot = structuredClone(before)
  const after = step(before, ['R', 'U'])
  assert.deepEqual(after.players.map(p => [p.x, p.y]), [[2, 1], [5, 2]])
  assert.equal(after.turn, 1)
  assert.deepEqual(before, snapshot)
  assert.notStrictEqual(after, before)
  assert.notStrictEqual(after.players, before.players)
})

run('walls, crates and board edge block movement', () => {
  const before = state({ players: [{ x: 2, y: 2, hp: 2 }, { x: 5, y: 3, hp: 2 }] })
  const after = step(before, ['R', 'D'])
  assert.deepEqual(after.players.map(p => [p.x, p.y]), [[2, 2], [5, 3]])
})

run('player and bomb occupancy block movement', () => {
  const a = state({ players: [{ x: 1, y: 1, hp: 2 }, { x: 2, y: 1, hp: 2 }] })
  assert.deepEqual(step(a, ['R', 'L']).players.map(p => [p.x, p.y]), [[1, 1], [2, 1]])
  const b = state({ players: [{ x: 1, y: 1, hp: 2 }, { x: 5, y: 3, hp: 2 }], bombs: [{ x: 2, y: 1, owner: 1, timer: 5, range: 2 }] })
  assert.deepEqual(step(b, ['R', 'S']).players[0], b.players[0])
})

run('new bomb starts at timer 2 then ticks on later turns', () => {
  const planted = step(state(), ['B', 'S'])
  assert.deepEqual(planted.bombs, [{ x: 1, y: 1, owner: 0, timer: 2, range: 2 }])
  const once = step(planted, ['S', 'S'])
  assert.equal(once.bombs[0].timer, 1)
  assert.deepEqual(once.lastBlast, [])
})

run('timer expiry explodes and damages player once', () => {
  const s = state({ bombs: [{ x: 1, y: 1, owner: 0, timer: 1, range: 2 }] })
  const after = step(s, ['S', 'S'])
  assert.equal(after.bombs.length, 0)
  assert.equal(after.players[0].hp, 1)
  assert(blastHas(after, 1, 1))
})

run('crate is blasted, destroyed, and stops that ray', () => {
  const s = state({ bombs: [{ x: 1, y: 2, owner: 0, timer: 1, range: 4 }] })
  const after = step(s, ['S', 'S'])
  assert(blastHas(after, 3, 2))
  assert(!blastHas(after, 4, 2))
  assert.equal(after.board[2][3], '.')
  assert.equal(s.board[2][3], '+')
})

run('permanent wall blocks without joining blast', () => {
  const board = ['#######', '#..#..#', '#.....#', '#.....#', '#######']
  const s = state({ board, bombs: [{ x: 1, y: 1, owner: 0, timer: 1, range: 4 }] })
  const after = step(s, ['S', 'S'])
  assert(blastHas(after, 2, 1))
  assert(!blastHas(after, 3, 1))
  assert(!blastHas(after, 4, 1))
})

run('blast chain triggers another positive-timer bomb', () => {
  const board = ['#######', '#.....#', '#.....#', '#.....#', '#######']
  const s = state({ board, bombs: [{ x: 1, y: 1, owner: 0, timer: 1, range: 2 }, { x: 3, y: 1, owner: 1, timer: 4, range: 2 }] })
  const after = step(s, ['S', 'S'])
  assert.equal(after.bombs.length, 0)
  assert(blastHas(after, 5, 1))
})

run('crate blocks chain until after explosions complete', () => {
  const board = ['#######', '#..+..#', '#.....#', '#.....#', '#######']
  const s = state({ board, bombs: [{ x: 1, y: 1, owner: 0, timer: 1, range: 4 }, { x: 5, y: 1, owner: 1, timer: 4, range: 2 }] })
  const after = step(s, ['S', 'S'])
  assert.equal(after.board[1][3], '.')
  assert.equal(after.bombs.length, 1)
  assert.equal(after.bombs[0].timer, 3)
  assert(!blastHas(after, 5, 1))
})

run('overlapping blasts damage a player only once', () => {
  const board = ['#######', '#.....#', '#.....#', '#.....#', '#######']
  const s = state({ board, players: [{ x: 2, y: 1, hp: 2 }, { x: 5, y: 3, hp: 2 }], bombs: [{ x: 1, y: 1, owner: 0, timer: 1, range: 2 }, { x: 3, y: 1, owner: 1, timer: 1, range: 2 }] })
  const after = step(s, ['S', 'S'])
  assert.equal(after.players[0].hp, 1)
  assert.equal(after.players[1].hp, 2)
})

run('single survivor wins and terminal state stays frozen', () => {
  const board = ['#######', '#.....#', '#.....#', '#.....#', '#######']
  const s = state({ board, players: [{ x: 5, y: 3, hp: 2 }, { x: 3, y: 1, hp: 1 }], bombs: [{ x: 1, y: 1, owner: 0, timer: 1, range: 2 }] })
  const after = step(s, ['S', 'S'])
  assert.equal(after.winner, 0)
  assert.equal(after.players[1].hp, 0)
  const frozen = step(after, ['L', 'B'])
  assert.deepEqual(frozen, after)
  assert.notStrictEqual(frozen, after)
  assert.notStrictEqual(frozen.players, after.players)
})

run('both players can die in a draw', () => {
  const board = ['#######', '#.....#', '#.....#', '#.....#', '#######']
  const s = state({ board, players: [{ x: 1, y: 1, hp: 1 }, { x: 2, y: 1, hp: 1 }], bombs: [{ x: 1, y: 1, owner: 0, timer: 1, range: 2 }] })
  const after = step(s, ['S', 'S'])
  assert.equal(after.winner, -1)
  assert.deepEqual(after.players.map(p => p.hp), [0, 0])
})

run('newly planted bomb can chain-trigger immediately', () => {
  const board = ['#######', '#.....#', '#.....#', '#.....#', '#######']
  const s = state({ board, players: [{ x: 4, y: 1, hp: 2 }, { x: 5, y: 3, hp: 2 }], bombs: [{ x: 2, y: 1, owner: 1, timer: 1, range: 2 }] })
  const after = step(s, ['B', 'S'])
  assert.equal(after.bombs.length, 0)
  assert(blastHas(after, 4, 1))
})

run('owner cannot plant a second active bomb; blast sorted unique', () => {
  const board = ['#######', '#.....#', '#.....#', '#.....#', '#######']
  const s = state({ board, bombs: [{ x: 4, y: 3, owner: 0, timer: 5, range: 2 }] })
  const after = step(s, ['B', 'S'])
  assert.equal(after.bombs.length, 1)
  assert.deepEqual(after.bombs[0], { x: 4, y: 3, owner: 0, timer: 4, range: 2 })
  const exploded = step(state({ board, bombs: [{ x: 2, y: 2, owner: 0, timer: 1, range: 2 }] }), ['S', 'S'])
  const sorted = [...exploded.lastBlast].sort((a, b) => a[1] - b[1] || a[0] - b[0])
  assert.deepEqual(exploded.lastBlast, sorted)
  assert.equal(new Set(exploded.lastBlast.map(p => p.join(','))).size, exploded.lastBlast.length)
})

const score = results.filter(x => x.pass).length
console.log(JSON.stringify({ file, score, total: results.length, results }, null, 2))
